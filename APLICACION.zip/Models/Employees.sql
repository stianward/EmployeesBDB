create table employees(
id SERIAL  primary key ,
fullname varchar(30)  not null ,
function_employee varchar(12)  not null 

) 
