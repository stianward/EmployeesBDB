import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Employee } from '../models/employee';
import { EmployeeService } from '../service/employee.service';
import {FormGroup, FormControl,Validators}from '@angular/forms';

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.css'],
})
export class EmployeeCreateComponent implements OnInit {
  fullName: string = '';
  functionEmployee: string = '';
  


  constructor(
    private employeeService: EmployeeService,
    private toastr: ToastrService,
    private router: Router,
 
  ) {}

  ngOnInit(): void {}
  createEmployee(): void {
    
    const employee = new Employee(this.fullName.toUpperCase(), this.functionEmployee.toUpperCase());
    this.employeeService.makeEmployee(employee).subscribe(
      (data) => {
        this.toastr.success('Employee created!', 'OK', { timeOut: 3000 });
        this.router.navigate(['/']);
      },
      (err) => {
        this.toastr.error('Employee NO created!', 'OK', { timeOut: 3000 });
        this.router.navigate(['/']);
      }
    );
  }
}
