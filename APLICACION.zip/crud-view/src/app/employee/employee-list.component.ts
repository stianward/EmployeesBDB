import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Employee } from '../models/employee';
import { EmployeeService } from '../service/employee.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees:Employee[]=[];

  constructor( private employeeService: EmployeeService,
    private toastr: ToastrService,
    private router: Router,
   ) { }
    
  ngOnInit(): void {
    this.EmployeeList();
  }


EmployeeList():void{
this.employeeService.listEmployee().subscribe(
  data=>{
    this.employees=data;
  },
  err=>{
    console.log("error")
  }
)

}
deleteEmployee(id:number){
  alert("Estas borrando el usuario con ID "+id);
  this.employeeService.deleteEmployee(id).subscribe(
    data=>{
      this.toastr.success('Employee Deleted!', 'OK', { timeOut: 3000 });
        this.router.navigate(['/']);
this.EmployeeList();
    },
    err=>{

      this.toastr.error('Employee NO created!', 'OK', { timeOut: 3000 });
      this.router.navigate(['/']);
    }
  )
}


}
