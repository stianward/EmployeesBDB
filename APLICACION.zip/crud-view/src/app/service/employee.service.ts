import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../models/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employeeURL='http://localhost:8080/emp/';

  constructor(private httpClient:HttpClient) {}
//Metodo que obtiene la lista de Employees

  public listEmployee():Observable<Employee[]>{
    return this.httpClient.get<Employee[]>(this.employeeURL+'listEmployee')
  }

//Metodo que crea un employee

  public makeEmployee(employee:Employee):Observable<any>{
    return this.httpClient.post<any>(this.employeeURL+'makeEmployee',employee);
  }

//Metodo que elimina un employee 

public deleteEmployee(id:number):Observable<any>{
  return this.httpClient.delete<any>(this.employeeURL+`deleteEmployee/${id}`);
}
}
