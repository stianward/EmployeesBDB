export class Employee {
  id?:number;
  fullName: string;
  functionEmployee: string;
  

  constructor(fullName: string, functionEmployee: string ) {
    this.fullName = fullName;
    this.functionEmployee = functionEmployee;
   
  }
}
