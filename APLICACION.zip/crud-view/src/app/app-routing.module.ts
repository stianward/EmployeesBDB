import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeCreateComponent } from './employee/employee-create.component';
import { EmployeeListComponent } from './employee/employee-list.component';

const routes: Routes = [
{path:'',component:EmployeeListComponent},
{path:'create',component:EmployeeCreateComponent},
{path:'**', redirectTo:'', pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
